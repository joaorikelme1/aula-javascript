//===============
// SHOWROOM JS
// Este arquiivo serve como laboratorio
// Selecao - eventos - manipulacao de textos
//settimeout e setintervout
//
//============-==
//1) SELECAO DE ELEMENTOS DO HTML (DOM)
//===============
//document -> representa toda a pagina HTML
//getElementById -> busca op elemento pelo atributo id
//
//
//Guardamos cada elemento em uma constante para reutilizar
//sem precisar buscar no html toda hora (boa pratica)

const saida = document.getElementById('saida');
const contadorSpan = document.getElementById('contador');
const relogioSpan = document.getElementById('relogio');
const toast = document.getElementById('toast');
const caixa = document.getElementById('caixa');
const inputNome = document.getElementById('nome');

//=============
//2) ESTADO SIMPLES (VARIAVEL)
//=============

let cliques = 0;

//3) FUNCAO UTILITARIA : ESCREVER NOS STATUS

function escreverStatus (mensagem) {
    saida.innerText = mensagem;
}

let toastTimer = null;

function mostrarToast(msg, tipo = 'info', tempoMs = 3000) {
    toast.style.display = 'block';
    toast.innerText = msg;

    if ( tipo === 'sucesso') {
        toast.style.borderColor = 'rgba(34, 197, 94, 0.6)';
    }
    else if (tipo === 'erro') {
        toast.style.borderColor = 'rgb(239, 68, 68)';
    }

    else {
        toast.style.borderColor = 'rgba(255, 255, 255, 0.12';
    }

    if(toastTimer) {
        clearTimeout(toastTimer);
    }

    toastTimer = setTimeout(()=> {
        toast.style.display = 'none'
    },
    tempoMs);
}

function atualizarContador() {
    contadorSpan.innerText = 'Cliques' + cliques;
}

function atualizarRelogio() {
    const agora = new Date();
    const h = String(agora.getHours()).padStart(2, '0')
    const m = String(agora.getMinutes()).padStart(2, '0')
    const s = String(agora.getSeconds()).padStart(2, '0')
    relogioSpan.innerText = `Hora: ${h}:${m}:${s}`;
}

setInterval(atualizarRelogio, 1000);

atualizarRelogio();